"""
djax
"""
__author__ = "Palash Bauri"
__version__ = "0.1"